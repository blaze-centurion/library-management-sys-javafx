-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2021 at 11:58 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `librarymanagement`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `bookId` int(8) NOT NULL,
  `bookname` varchar(100) NOT NULL,
  `bookImg` varchar(100) NOT NULL,
  `category` int(3) NOT NULL,
  `totalBooks` int(9) NOT NULL DEFAULT 0,
  `availableBooks` int(9) NOT NULL DEFAULT 0,
  `issuedBook` int(9) NOT NULL DEFAULT 0,
  `popularity` int(8) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`bookId`, `bookname`, `bookImg`, `category`, `totalBooks`, `availableBooks`, `issuedBook`, `popularity`) VALUES
(348428, 'Learn Python For Free', 'images/14-50-36-Screenshot (18).png', 1, 303, 302, 1, 2),
(1307990, 'any book', 'images/15-02-27-IMG_20210326_19001932.jpg', 2, 20, 20, 0, 0),
(6218264, 'some name', 'images/10-26-52-20171019_172440.jpg', 2, 23, 22, 1, 1),
(7015678, 'Hello World', 'images/20-29-02-c++2.jpg', 1, 14, 12, 2, 2),
(7093029, 'Programming Python', 'images/python1.jpg', 1, 7, 4, 3, 5),
(8463992, 'Nothing', 'images/19-18-36-c++.jpg', 1, 25, 23, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `book_his`
--

CREATE TABLE `book_his` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `bookname` varchar(100) NOT NULL,
  `userId` int(11) NOT NULL,
  `bookId` int(11) NOT NULL,
  `issuedAt` varchar(10) NOT NULL,
  `returnAt` varchar(10) NOT NULL DEFAULT '0',
  `fine` int(9) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book_his`
--

INSERT INTO `book_his` (`id`, `username`, `bookname`, `userId`, `bookId`, `issuedAt`, `returnAt`, `fine`) VALUES
(1, 'roshan', 'Programming Python', 7450686, 7093029, '14-06-2021', '16-06-2021', 20),
(2, 'roshan', 'Programming Python', 7450686, 7093029, '18-06-2021', '23-06-2021', 0),
(3, 'roshan', 'Hello World', 7450686, 7015678, '22-06-2021', '0', 0),
(5, 'roshan', 'voo', 7450686, 685690, '23-06-2021', '0', 0),
(6, 'roshan', 'Programming Python', 7450686, 7093029, '23-06-2021', '0', 0),
(7, 'librarian', 'voo', 8548570, 685690, '23-06-2021', '0', 0),
(8, 'librarian', 'Programming Python', 8548570, 7093029, '23-06-2021', '0', 0),
(9, 'librarian', 'Nothing', 8548570, 8463992, '23-06-2021', '0', 0),
(10, 'roshan', 'Learn Python For Free', 2196641, 348428, '30-07-2021', '30-07-2021', 0),
(11, 'roshan', 'voo', 2196641, 685690, '30-07-2021', '30-07-2021', 0),
(12, 'roshan', 'some name', 2196641, 6218264, '30-07-2021', '0', 0),
(13, 'roshan', 'Hello World', 2196641, 7015678, '30-07-2021', '0', 0),
(14, 'roshan', 'Programming Python', 2196641, 7093029, '30-07-2021', '0', 0),
(15, 'roshan', 'Nothing', 2196641, 8463992, '30-07-2021', '0', 0),
(16, 'roshan', 'voo', 2196641, 685690, '30-07-2021', '0', 0),
(17, 'roshan', 'Learn Python For Free', 2196641, 348428, '30-07-2021', '0', 0);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `catId` int(11) NOT NULL,
  `catName` varchar(45) NOT NULL,
  `availableBooks` int(11) NOT NULL DEFAULT 0,
  `totalBook` int(11) NOT NULL DEFAULT 0,
  `popularity` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`catId`, `catName`, `availableBooks`, `totalBook`, `popularity`) VALUES
(1, 'programming', 341, 349, 11),
(2, 'entertainment', 112, 113, 5),
(3, 'Maths', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `fine_his`
--

CREATE TABLE `fine_his` (
  `username` varchar(100) NOT NULL,
  `bookname` varchar(100) NOT NULL,
  `userId` int(11) NOT NULL,
  `bookId` int(11) NOT NULL,
  `reason` varchar(150) NOT NULL,
  `issuedAt` varchar(10) NOT NULL,
  `fine` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fine_his`
--

INSERT INTO `fine_his` (`username`, `bookname`, `userId`, `bookId`, `reason`, `issuedAt`, `fine`) VALUES
('roshan', 'Programming Python', 7450686, 7093029, 'Damage', '14-06-2021', 20);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `email` varchar(90) NOT NULL,
  `password` varchar(150) NOT NULL,
  `role` int(4) NOT NULL,
  `userProfile` varchar(100) NOT NULL,
  `totalBooks` int(7) NOT NULL DEFAULT 0,
  `totalFine` int(7) NOT NULL DEFAULT 0,
  `issuedBook` int(7) NOT NULL DEFAULT 0,
  `joinon` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `username`, `email`, `password`, `role`, `userProfile`, `totalBooks`, `totalFine`, `issuedBook`, `joinon`) VALUES
(2196641, 'roshan', 'roshan@mail.com', '$2a$12$E98XYVdYa1tUrImkwWRpTunLmTr/Xnc9W0VfIeFOXeB9O6c1Bo2OK', 0, 'images/user.png', 8, 0, 8, '30/07/2021'),
(7094529, 'admin', 'admin@mail.com', '$2a$12$vyzsOBCfa3uxFLSiyDCQ5uIBzEhjxoQX7FCDB4kgB5eP/CQvcx9Qu', 2, 'images/user.png', 0, 0, 0, '14/06/2021'),
(7450686, 'roshan sharma', 'roshan@mail.com', '$2a$12$CImzGqvGYAzTHi7F4eKO3eOKOcpi6oKZ2oG0v6qaZeA9IGWjZQ8Aa', 0, 'images/21-22-36-IMG-20200618-WA0000.jpg', 4, 20, 3, '14/06/2021'),
(8548570, 'librarian', 'librarian@mail.com', '$2a$12$Jf5letvXv76JQZQOAXurj.zM8rEufeWaNqQ8KeHT9t6PFa.LwYzNW', 1, 'images/user.png', 3, 0, 3, '14/06/2021');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD UNIQUE KEY `bookId` (`bookId`);

--
-- Indexes for table `book_his`
--
ALTER TABLE `book_his`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`catId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD UNIQUE KEY `userid` (`userid`,`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_his`
--
ALTER TABLE `book_his`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `catId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
